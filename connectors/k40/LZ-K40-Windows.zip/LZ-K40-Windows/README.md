# LZ K40 · conector 0.4.1 para Box Studio

Control por USB para M2 Nano conservando libusb-win32 y Sagaon/K40 Whisperer.
El navegador usa un conector local; no hay que descargar/importar diseños para
cada trabajo. La potencia se ajusta en el panel físico de la M2.

## Instalar o actualizar una vez en Windows

1. Termina cualquier trabajo. Cierra el conector anterior y Sagaon.
2. Extrae **LZ-K40-Windows.zip** en una carpeta fija, por ejemplo
   `Documentos\LZ-K40`. No lo ejecutes dentro del ZIP ni borres/muevas esa carpeta.
3. Ejecuta **instalar-windows.bat**. Requiere Python 3.10 o posterior con el comando
   `py` y Tkinter de la instalación oficial. Instala dependencias en su `.venv`,
   comprueba el motor sin USB, activa el inicio automático y abre el panel local.
4. Pulsa **Copiar código** y pégalo una vez en Box. Deja **Recordar esta computadora**
   marcado. Si ya estaba emparejado, el código se conserva y no se repite este paso.
5. En adelante, el conector inicia en segundo plano al iniciar sesión en Windows.
   Abre Box y pulsa **Controlar mi K40**: el panel recupera el código e intenta
   conectar. No inicia movimientos ni cortes al abrirse.

El inicio automático escribe únicamente el valor `LZStudioK40` en
`HKCU\Software\Microsoft\Windows\CurrentVersion\Run`; ejecuta `pythonw.exe`
con `background.pyw`, sin consola. No instala servicios ni pide administrador.
No abre/retiene USB hasta conectar desde Box. No modifica drivers ni Sagaon.
El perfil de segundo plano usa cama **400 × 400 mm**, no una calibración.

Para abrir el panel local manualmente usa **abrir-conector.vbs**. Permite copiar
el código, ver el estado, abrir Box y activar/desactivar el inicio automático.
**Cerrar conector** rechaza la operación si hay trabajo pendiente. Cerrar solo
la ventana del panel mantiene el conector en segundo plano.

**desactivar-inicio-windows.bat** quita exclusivamente su entrada de inicio para
las próximas sesiones. **activar-inicio-windows.bat** la vuelve a crear y arranca
el conector. Si mueves la carpeta, vuelve a activar desde la nueva ubicación.

## Mover el cabezal y elegir origen

1. Con la emisión físicamente deshabilitada, conecta y verifica que el recorrido
   esté libre. Pulsa **Home** una vez para establecer la referencia de la sesión.
2. Usa las flechas: un clic es un movimiento de 0.1, 1, 5, 10, 25 o 50 mm.
   No se acumulan pulsaciones mientras la controladora no indique fin.
3. En la posición deseada pulsa **Usar esta posición como origen**. La vista
   alinea la esquina superior izquierda del contorno del diseño con el cabezal.
4. Prueba **Recorrer marco sin láser**. En origen actual no se ejecuta Home.
   Al terminar el marco o corte vuelve al origen elegido, no al otro lado de la cama.
5. Valida direcciones, escala, límites y cancelación antes de habilitar la emisión.
   Después puedes enviar la hoja desde Box, sin descargar SVG/DXF.

La posición es **estimada a partir de las órdenes**, no medida por un encoder.
Se descarta al cancelar, perder comunicación, reiniciar o liberar el USB. Si mueves
el cabezal a mano, libera/reconecta y establece Home. El modo **Desde Home** sigue
existiendo para los trabajos que deban referenciarse a la esquina de la cama.

El conector valida nuevamente los límites después de situar el diseño en el
origen actual. No envía coordenadas EGV arbitrarias, comandos de consola ni archivos
recibidos por HTTP. Los movimientos se compilan con el driver M2 de MeerK40t
0.9.9100; Home, flechas y marco no incluyen órdenes de encendido del láser.
El motor requiere confirmación de cada paquete; una comunicación fallida no se
reanuda automáticamente. Las pruebas de protocolo no sustituyen la prueba física.

## Cancelación y uso de Sagaon

**Cancelar y solicitar parada** permanece disponible durante envío y fin de datos.
Descarta la cola y solicita el reinicio prioritario soportado por MeerK40t.
La cancelación ya no espera el candado del envío: interrumpe las esperas normales
y bloquea nuevas escrituras del trabajo, conservando el envío del reinicio.
Una transferencia USB ya iniciada puede terminar; la parada física inmediata no
está garantizada por software.
No sustituye al paro físico: si continúa, utiliza el paro físico de la máquina.
**Confirmar máquina detenida** queda para cancelación/error o comunicación desconocida.
En operación normal, Home, flechas, marco y corte vuelven a estar listos
automáticamente cuando la controladora indica fin; enviar datos no basta.
Se eliminó la casilla repetitiva: cada botón inicia solamente su propia operación.
El porcentaje solo mide datos transmitidos. La parada modificada requiere
validación física con emisión deshabilitada antes de otro corte.

Después de terminar un trabajo normal se conserva la conexión y el origen,
para evitar reconectar en cada hoja. Después de cancelación/error se descarta la
posición y se requiere reconectar. Para Sagaon pulsa **Liberar USB para Sagaon**.
Usa solo un programa a la vez. No se garantiza que WebUSB funcione con libusb-win32;
este panel vuelve al conector local que funcionó con el driver existente.

## Emparejamiento y recuperación

El secreto se conserva en `%LOCALAPPDATA%\LZStudioTools\K40\pairing.json`, fuera
del código. No se incluye en URLs ni se manda a Vercel. El navegador lo guarda
únicamente para el origen/perfil actual si marcas Recordar. Cambiar entre la URL
de prueba y producción requiere emparejar ese origen una vez. Olvidar código lo
borra de ese navegador. `bridge.py --reset-pairing` lo rota al iniciar el conector.

El conector escucha solo en **127.0.0.1:17840**, con Origin exacto y token. Una
segunda instancia no reemplaza el código. El registro local de errores está en
el mismo directorio de datos (`connector.log`) y no registra el código.
Si cierras/reabres el panel web durante una operación, recupera el estado sin
reenviar el trabajo. No prepares de nuevo un corte cuya respuesta se haya perdido.

## Verificación y desarrollo

- Probados en Linux: compilador real M2 sin abrir USB; movimientos y fin de
  controladora con transporte de prueba; origen, límites, cancelación, sesión,
  persistencia del código y arranque/cierre HTTP en segundo plano sin USB.
- Probado el flujo DOM del panel, geometría de 17 modelos y vista de origen actual.
- La instalación, el panel Tkinter y la entrada de inicio requieren verificación
  en Windows. Las pruebas del registro usan un sustituto, no modifican el sistema.
- Pendientes: revisión visual en navegador del nuevo panel y prueba física con
  emisión deshabilitada. No se declara idéntico a K40 Whisperer ni listo para producción.

```sh
npm ci
node --test k40-tests.mjs
python -m pip install -r connectors/k40/requirements.txt
python -m unittest discover -s connectors/k40 -p 'test_*.py' -v
PYTHON=python node k40-http-integration.mjs
npm run build:vercel
node vercel-tests.mjs
```

Se conservan **simular-windows.bat** (sin USB) y **usb-windows.bat** (con consola)
para diagnóstico. No ejecutes ambos junto al conector de segundo plano.

Referencias: https://github.com/meerk40t/meerk40t (MIT),
https://www.scorchworks.com/K40whisperer/k40w_manual.html y
https://support.microsoft.com/es-es/windows/experience/startup-boot/configure-startup-applications-in-windows .
No se redistribuyen binarios de MeerK40t ni de los controladores; se instalan las
dependencias fijadas en requirements.txt. Conserva sus licencias al empaquetarlas.
